//module.exports
//require functionalities

/* 
./ means: “current directory” — the folder where your current 
JavaScript file is located.
*/
const firstmodule= require("./first_module");

console.log(firstmodule.add(10,20))

try
{
    console.log("trying divide by zero")
    let result=firstmodule.divide(10,0);
    console.log(result)
}
catch(error){
    console.log("caught an error", error.message);
}
try
{
    let result=firstmodule.divide(0,10);
    console.log(result)
}
catch(error){
    console.log("caught an error", error.message);
}
