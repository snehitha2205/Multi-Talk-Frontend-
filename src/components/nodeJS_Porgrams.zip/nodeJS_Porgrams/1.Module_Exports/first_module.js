/*moudle.exports:
--------------------
--->it’s one of the most important concepts for organizing and reusing code.

-->In Node.js, exports is an object that allows you to expose (export)functions,
variables, or classes from one file (module) so they can be imported (required)
into another file.

-->In Node.js, every file is treated as a separate module, 
and module.exports is the object that is actually returned when another file
uses require() to import it.

So basically:Whatever you assign to module.exports becomes
the public interface of your module.

Internal Working:
------------------
When Node.js loads a file, it wraps your code like this:

(function (exports, require, module, __filename, __dirname) {
    // your code here
});

That’s why every file automatically has:
----------------------------------------
exports
module
require
__filename
__dirname
Here, module.exports starts as an empty object {}.
*/
//console.log("moduleexports");
function add(a,b)
{
    return a+b;
}
function sub(a,b)
{
    return a-b;
}
function divide(a,b)
{
    if(b==0)
    {
        throw new Error("divide by zero is not allowed")
    }
    return a/b;
}

module.exports={add,sub,divide};