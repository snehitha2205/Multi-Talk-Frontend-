/*
-->The http module is the foundation of all web servers in Node.js.
-->It allows your JavaScript code to handle requests, send responses, 
-->and build APIs or web apps — even before using frameworks like Express.js.


Exmaple-1: how to create http sever 

-> for creating http server we require http model Here import http  and 

use createServer method which contains req&res,

When you use http.createServer(callback):
-------------------------------------------
req = Incoming HTTP Request object
res = HTTP Response object
These are automatically passed by Node.js when someone accesses your server (for example, from a browser).

-->we require listen method which contains port number(example: 3000)
now  http server is created (open browser type-localhost:3000) 

in this program , if u run in brower (localhost:3000) it is loading continuosly 
*/

const http=require('http')

const server=http.createServer((req,res)=>{

    console.log(req,"req");

});

const port=3000;
server.listen(port,()=>{
    console.log(`server is now listening to port ${port}`)
})