/*
What is the os Module in Node.js?
----------------------------------
The os module provides system-related information — like your computer’s:
Operating system name
CPU info
Memory usage
Network interfaces
System uptime, etc.

It is a built-in core module — no installation needed.
You can import it using: const os = require('os');


*/
/*1.Getting OS Platform:  Method: os.platform()

Returns the platform name (win32, linux, darwin, etc.).

*/

const os = require('os');
console.log("Operating System Platform:", os.platform());

//Output: Operating System Platform: win32



/*2. Getting OS Type: Method: os.type()

Returns the name of the operating system.
*/

console.log("Operating System Type:", os.type());

//Output:  Operating System Type: Windows_NT

/*3. Getting OS Release: Method: os.release()

Returns the version of the operating system.
*/
console.log("OS Release:", os.release());

//Output: OS Release: 10.0.26100


/*4. Getting System Architecture: Method: os.arch()

Returns the CPU architecture (x64, arm, etc.)*/


console.log("System Architecture:", os.arch());

//Output:  System Architecture: x64

/*5. Getting Total and Free Memory

Methods: os.totalmem() → total system memory in bytes

os.freemem() → free memory in bytes

*/
console.log("Total Memory:", os.totalmem() / (1024 * 1024 * 1024), "GB");
console.log("Free Memory:", os.freemem() / (1024 * 1024 * 1024), "GB");

/*Output:
otal Memory: 7.784477233886719 GB
Free Memory: 1.5749969482421875 GB
*/

/*6. Getting Home Directory: Method: os.homedir()

Returns the path of the current user’s home directory.

*/

console.log("Home Directory:", os.homedir());

//Output:  Home Directory: C:\Users\rrgur

/*7. Getting System Uptime: Method: os.uptime()

Returns the system uptime in seconds (how long the system has been running).
*/

console.log("System Uptime:", os.uptime(), "seconds");

//Output: System Uptime: 269649.75 seconds

//(You can convert to hours: os.uptime() / 3600)

/*8. Getting Current User Info: Method: os.userInfo()
Returns details about the current logged-in user.
*/

console.log("User Info:", os.userInfo());

/*Output:
User Info: [Object: null prototype] {
  uid: -1,
  gid: -1,
  username: 'rrgur',
  homedir: 'C:\\Users\\rrgur',
  shell: null
}
*/

/*9. Getting CPU Information: Method: os.cpus()

Returns details about each logical CPU core.

*/

const cpus = os.cpus();
console.log("CPU Information:");
console.log(cpus);
console.log("Number of CPU cores:", cpus.length);

/*output:
CPU Information:
[
  {
    model: '11th Gen Intel(R) Core(TM) i3-1115G4 @ 3.00GHz',
    speed: 2995,
    times: {
      user: 7633078,
      nice: 0,
      sys: 7196328,
      idle: 93934390,
      irq: 881593
    }
  },
  {
    model: '11th Gen Intel(R) Core(TM) i3-1115G4 @ 3.00GHz',
    speed: 2995,
    times: {
      user: 6456468,
      nice: 0,
      sys: 5387546,
      idle: 96919750,
      irq: 288234
    }
  },
  {
    model: '11th Gen Intel(R) Core(TM) i3-1115G4 @ 3.00GHz',
    speed: 2995,
    times: {
      user: 6381843,
      nice: 0,
      sys: 4949062,
      idle: 97432859,
      irq: 257671
    }
  },
  {
    model: '11th Gen Intel(R) Core(TM) i3-1115G4 @ 3.00GHz',
    speed: 2995,
    times: {
      user: 5469406,
      nice: 0,
      sys: 4572421,
      idle: 98721937,
      irq: 222421
    }
  }
]
Number of CPU cores: 4
*/

/* 10. Getting Network Interfaces: Method: os.networkInterfaces()
Returns details of network adapters (IP addresses, MAC address, etc.)

*/

console.log("Network Interfaces:", os.networkInterfaces());
/* Output:
Network Interfaces: {
  Wi-Fi: [
    {
      address: '192.168.1.4',
      netmask: '255.255.255.0',
      family: 'IPv4',
      mac: 'b8:27:eb:45:12:34',
      internal: false
    }
  ]
}
  Network Interfaces: {
  'Wi-Fi': [
    {
      address: '2405:201:c005:8834:5f9d:5720:f159:ee6f',
      netmask: 'ffff:ffff:ffff:ffff::',
      family: 'IPv6',
      mac: 'f8:9e:94:ae:bf:d2',
      internal: false,
      cidr: '2405:201:c005:8834:5f9d:5720:f159:ee6f/64',
      scopeid: 0
    },
    {
      address: '2405:201:c005:8834:e098:f00f:79c2:8869',
      netmask: 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff',
      family: 'IPv6',
      mac: 'f8:9e:94:ae:bf:d2',
      internal: false,
      cidr: '2405:201:c005:8834:e098:f00f:79c2:8869/128',
      scopeid: 0
    },
    {
      address: 'fe80::563d:bf01:5e5a:25ee',
      netmask: 'ffff:ffff:ffff:ffff::',
      family: 'IPv6',
      mac: 'f8:9e:94:ae:bf:d2',
      internal: false,
      cidr: 'fe80::563d:bf01:5e5a:25ee/64',
      scopeid: 17
    },
    {
      address: '192.168.29.5',
      netmask: '255.255.255.0',
      family: 'IPv4',
      mac: 'f8:9e:94:ae:bf:d2',
      internal: false,
      cidr: '192.168.29.5/24'
    }
  ],
  'Loopback Pseudo-Interface 1': [
    {
      address: '::1',
      netmask: 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff',
      family: 'IPv6',
      mac: '00:00:00:00:00:00',
      internal: true,
      cidr: '::1/128',
      scopeid: 0
    },
    {
      address: '127.0.0.1',
      netmask: '255.0.0.0',
      family: 'IPv4',
      mac: '00:00:00:00:00:00',
      internal: true,
      cidr: '127.0.0.1/8'
    }
  ]
}
*/

/*11. Getting Temporary Directory: Method: os.tmpdir()
 Returns the default temp folder path.

*/

console.log("Temporary Directory:", os.tmpdir());

/*Output:

Temporary Directory: C:\Users\rrgur\AppData\Local\Temp

*/


/*12. Getting Endianness: Method: os.endianness()

Returns 'BE' (Big Endian) or 'LE' (Little Endian).
It shows how bytes are ordered in memory.
*/

console.log("System Endianness:", os.endianness());

//Output: System Endianness: LE

/* 13. Getting Hostname: Method: os.hostname()

🔹 Returns the computer’s hostname.

*/
console.log("Host Name:", os.hostname());

//Output:Host Name: rrgurrala

/*14. Checking Load Average (Linux/macOS only) 
Method: os.loadavg()
Returns CPU load average for the last 1, 5, and 15 minutes.
(Works on Linux/macOS, not on Windows.)

*/
console.log("Load Average:", os.loadavg());

//Output: Load Average: [ 0, 0, 0 ]


/*Complete Example Code

You can combine everything like this:

const os = require('os');

console.log("======== SYSTEM INFORMATION ========");
console.log("Hostname:", os.hostname());
console.log("Platform:", os.platform());
console.log("Type:", os.type());
console.log("Release:", os.release());
console.log("Architecture:", os.arch());
console.log("Total Memory:", (os.totalmem() / 1024 / 1024 / 1024).toFixed(2), "GB");
console.log("Free Memory:", (os.freemem() / 1024 / 1024 / 1024).toFixed(2), "GB");
console.log("Home Directory:", os.homedir());
console.log("Uptime (hours):", (os.uptime() / 3600).toFixed(2));
console.log("User Info:", os.userInfo());
console.log("CPU Cores:", os.cpus().length);
console.log("Network Interfaces:", os.networkInterfaces());
console.log("Temp Directory:", os.tmpdir());
console.log("Endianness:", os.endianness());

*/

/*
Summary Table
--------------
Method	            Description	            Example Output
os.platform()	    OS Platform     	    win32
os.type()	        OS Name	                Windows_NT
os.release()	    OS Version	            10.0.19045
os.arch()	        CPU Architecture	    x64
os.totalmem()	    Total Memory	        16 GB
os.freemem()	    Free Memory	            4 GB
os.homedir()	    Home Directory	        C:\Users\KMIT
os.uptime()	        System Uptime (sec)	    48572
os.userInfo()	    User Details	        { username: 'KMIT' }
os.cpus()	        CPU Info	            Array of cores
os.networkInterfaces()	Network Info	    IP/MAC details
os.tmpdir()	        Temp Folder	            C:\Temp
os.endianness() 	Memory Order	        LE
os.hostname()	    Host Name	            KMIT-PC
os.loadavg()	    Load Avg	            [0.12, 0.18, 0.22]

*/