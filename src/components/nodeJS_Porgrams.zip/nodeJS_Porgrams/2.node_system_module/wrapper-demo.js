/*
Node.js automatically provides these two special global variables inside every 
module (file):

| Variable         | Meaning                                                                              |
| ---------------- | ------------------------------------------------------------------------------------ |
| **`__filename`** | The full **absolute path** of the current file (including file name).                |
| **`__dirname`**  | The full **absolute path** of the folder (directory) that contains the current file. |

They help you identify where your current script is located in your file system.

These are very helpful when you need to:
------------------------------------------
Load files relative to your current script
Build correct file paths
Avoid hardcoding full paths
*/

const wrapperExplorer= require("./wrapper-explorer.js");

console.log(`wrapper demo class contains`);

console.log("_filenmae", __filename);

console.log("_dirname",__dirname);

wrapperExplorer.greet("john");