//You can pass arguments to the event handler by passing 
// them as additional arguments to emit():

const EventEmitter = require('node:events');

const eventEmitter = new EventEmitter();


eventEmitter.on('start', number => {
  console.log(`started ${number}`);
});

eventEmitter.emit('start', 23);
