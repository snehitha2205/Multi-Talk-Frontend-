//Example-2: custom –event listener:

const EventEmitter = require('node:events');

class MycustomEmitter extends EventEmitter
{
     constructor()
     {
        super();
        this.greeting='hello'
     }

     greet(name)
     {
        this.emit('greeting',`${this.greeting},${name}`)
     }
}

const mycustomEmitter = new MycustomEmitter();

mycustomEmitter.on("greeting",(input)=>
{
    console.log(`Greeting Event`,input);
})

mycustomEmitter.greet(" Hello John")