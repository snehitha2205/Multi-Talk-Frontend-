// callbak Example-1

function person(name,callbackFn)
{
    console.log(`Hello ${name}`)
    callbackFn()
}

function address(){
console.log("Hyderabad")
}

person("KMIT",address);

/*output:
Hello KMIT
Hyderabad
*/
