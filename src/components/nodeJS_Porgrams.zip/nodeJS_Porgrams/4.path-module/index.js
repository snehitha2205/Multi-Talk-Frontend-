/*What is the path module?

the path module in Node.js is one of the most important built-in (core) 
modules for handling and working with file and directory paths in a clean, 
platform-independent way.

The path module helps you work with file and folder paths easily in Node.js.
It is a core module, so you don’t need to install it — just require('path').
It makes your code cross-platform (works on both Windows \ and Linux / paths).
*/
const path=require("path");

//get directory
console.log("directory name is :", path.dirname(__filename));

//get file names
console.log("file name is:", path.basename(__filename));

// get file extensions
console.log("file extensions",path.extname(__filename));

//join path:It automatically adds or removes slashes (/ or \) as needed.

const joinpath=path.join("/users","documents","node","projects");

console.log("joined path is:",joinpath);

//resolve path:Resolves a sequence of paths into an absolute path.
const resolvepath=path.resolve("user","documents","node","projects");

console.log("Resolve path is:",resolvepath);
/*
Differences:
join() → joins relative paths.
resolve() → always gives absolute path starting from root.
*/



//Normalizing paths:Cleans up a messy path (removes .., ., and duplicate slashes).
const normalizepath=path.normalize("/user/.documents/../node/projects");
console.log("normalize path",normalizepath);

//parse(path):Returns an object with useful details about the file path.
const info = path.parse('/user/local/test/data.txt');
console.log(info);


//we can also rebuild a path using:
const rebuilt = path.format(info);
console.log(rebuilt); // /user/local/test/data.txt

//isAbsolute(path): Checks if the given path is absolute.
console.log(path.isAbsolute('/user/local')); // true
console.log(path.isAbsolute('data/file.txt')); // false


/*Summary table:

| Method              | Description               | Example Output                 |
| ------------------- | ------------------------- | ------------------------------ |
| `path.join()`       | Joins paths safely        | `C:\a\b\c.txt`                 |
| `path.resolve()`    | Resolves to absolute path | `C:\project\a\b.txt`           |
| `path.basename()`   | File name                 | `b.txt`                        |
| `path.dirname()`    | Folder path               | `C:\project\a`                 |
| `path.extname()`    | Extension                 | `.txt`                         |
| `path.parse()`      | Breaks into parts         | `{root, dir, base, ext, name}` |
| `path.isAbsolute()` | Checks absolute path      | `true / false`                 |
| `path.normalize()`  | Cleans messy path         | `/user/test/file.txt`          |

*/
