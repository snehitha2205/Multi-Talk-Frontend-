

const lodash=require("lodash");
const names=["john","alexa","terry","maria"];
const result=lodash.map(names,lodash.capitalize);
console.log(result);
